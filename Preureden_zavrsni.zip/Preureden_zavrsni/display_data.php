<?php
$servername = "tsz.myftp.org";
$username = "24lpesic";
$password = "12d845bbc8";
$dbname = "e1_24_lpesic";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT exerciseDate, SUM(exerciseTime) AS totalExerciseTime FROM exercise_daily_time GROUP BY exerciseDate";
$result = mysqli_query($conn, $sql);

$data = array();

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = array(
        'date' => $row['exerciseDate'],
        'time' => $row['totalExerciseTime'] // Ukupno vrijeme za taj datum
    );
}

echo json_encode($data);

mysqli_close($conn);