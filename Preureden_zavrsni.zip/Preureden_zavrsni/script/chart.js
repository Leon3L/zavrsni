

const xWValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

new Chart("myWeightChart", {
    type: "line",
    data: {
        labels: xWValues,
        datasets: [{
            data: [86, 85.8, 86.4, 84, 82.7, 82.8, 81, 80, 79.5, 78],
            borderColor: "rgba(0,255,255,0.7)",
            fill: false
        }]
    },
    options: {
        legend: {display: false},
        scales: {
            yAxes: [{
                ticks: {
                    fontColor: 'white'
                }
            }],
            xAxes: [{
                ticks: {
                    fontColor: 'white'
                }
            }]
        },
        title: {
            display: true,
            text: 'Weight/Day',
            fontColor: 'white'
        }
    }
});

