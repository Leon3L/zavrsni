<?php
$servername = "tsz.myftp.org";
$username = "24lpesic";
$password = "12d845bbc8";
$dbname = "e1_24_lpesic";

// Stvori vezu s bazom podataka
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Provjeri vezu
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
/*
// SQL upit za dodavanje stupca i definiranje ograničenja vanjskog ključa u tablici exercise_diary
$sql_diary = "
    ALTER TABLE exercise_diary
    ADD COLUMN user_id INT,
    ADD CONSTRAINT fk_user_id_diary FOREIGN KEY (user_id) REFERENCES exercise_user(id)
";

// Izvrši upit
if (mysqli_query($conn, $sql_diary)) {
    echo "Stupac i ograničenje vanjskog ključa uspješno dodani u tablici exercise_diary<br>";
} else {
    echo "Greška pri izvršavanju upita: " . mysqli_error($conn) . "<br>";
}

// SQL upit za dodavanje stupca i definiranje ograničenja vanjskog ključa u tablici exercise_daily_time
$sql_daily_time = "
    ALTER TABLE exercise_daily_time
    ADD COLUMN user_id INT,
    ADD CONSTRAINT fk_user_id_daily_time FOREIGN KEY (user_id) REFERENCES exercise_user(id)
";

// Izvrši upit
if (mysqli_query($conn, $sql_daily_time)) {
    echo "Stupac i ograničenje vanjskog ključa uspješno dodani u tablici exercise_daily_time<br>";
} else {
    echo "Greška pri izvršavanju upita: " . mysqli_error($conn) . "<br>";
}

// Zatvori vezu s bazom podataka
mysqli_close($conn);
/*
 * <?php
$servername = "tsz.myftp.org";
$username = "24lpesic";
$password = "12d845bbc8";

$conn = mysqli_connect($servername, $username, $password, "e1_24_lpesic");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql="ALTER TABLE exercise_diary
ADD COLUMN user_id INT,
ADD CONSTRAINT fk_user_id_diary FOREIGN KEY (user_id) REFERENCES exercise_user(id);)";
if (mysqli_query($conn, $sql)) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
/*
-- Dodaj stupac u tablici exercise_daily_time
ALTER TABLE exercise_daily_time
ADD COLUMN user_id INT,
ADD CONSTRAINT fk_user_id_daily_time FOREIGN KEY (user_id) REFERENCES exercise_user(id);





/*
$sql="CREATE TABLE exercise_last_user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES exercise_user(id)
)";
if (mysqli_query($conn, $sql)) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
/*
$sql = "CREATE TABLE exercise_user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    password VARCHAR(20) NOT NULL,
    height INT(3) NOT NULL,
    weight INT(3) NOT NULL,
    gender ENUM('male', 'female') NOT NULL
)";
if (mysqli_query($conn, $sql)) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
/*

$sql = "CREATE TABLE exercise_diary (
id INT(6) AUTO_INCREMENT PRIMARY KEY,
exerciseDate DATE,
squats int(10),
lunges int(10),
calfRaises int(10),
wallSits int(10),
running int(10),
ropeJumps int(10),
burpees int(10),
jumpingJacks int(10),
pushUps int(10),
diamondPU int(10),
declinePU int(10),
pikePU int(10),
bodyWeightRows int(10),
pullUps int(10),
dips int(10),
plank int(10),
sidePlank int(10),
legRaises int(10),
abCrunches int(10),
heelTouches int(10),
bycicleCrunches int(10)
)";

if (mysqli_query($conn, $sql)) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}


/*
$sql = "CREATE TABLE exercise_data (
id_exercise INT(6) AUTO_INCREMENT PRIMARY KEY,
exercise_name varchar(20),
exercise_time decimal(4,1)
)";

if (mysqli_query($conn, $sql)) {
echo "Table users created successfully";
} else {
echo "Error creating table: " . mysqli_error($conn);
}

*/

/*
$sql = "INSERT INTO exercise_data (exercise_name, exercise_time) VALUES ('Squats', 2.1),
                                                                ('Lunges', 2.7),
                                                                ('Calf Raises', 1.2),
                                                                ('Wall sits',1),
                                                                ('Running',1),
                                                                ('Rope jumps',0.6),
                                                                ('Burpees',3.2),
                                                                ('Jumping jacks',0.9)";
if (mysqli_query($conn, $sql)) {
    echo "Record inserted successfully";
} else {
    echo "Error inserting record: " . mysqli_error($conn);
}
*/

/*
$sql = "CREATE TABLE exercise_log (
id_log INT(6) AUTO_INCREMENT PRIMARY KEY,
date DATE,
exercise_id INT(6),
reps INT(5),
FOREIGN KEY (exercise_id) REFERENCES exercise_data(id)
)";

if (mysqli_query($conn, $sql)) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
*/

// Close connection
mysqli_close($conn);
 */